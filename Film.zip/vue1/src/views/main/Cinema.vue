<template>
  <div>影院选择</div>
</template>

<script>
export default {

}

</script>

<style>

</style>