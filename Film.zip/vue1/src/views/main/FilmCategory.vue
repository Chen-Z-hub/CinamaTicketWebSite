<template>
  <p>电影搜索</p>
</template>

<script>
export default {

}
</script>

<style>

</style>