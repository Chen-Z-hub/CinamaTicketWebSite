<template>
    <el-container>
        <el-header>Header</el-header>
        <el-container>
            <el-main><!--main-->
                <div class="movie-list">
                    <h3 class="title">正在热映></h3>
                    <el-row :gutter="30">
                        <el-col :span="8" v-for="(movie, index) in movies" :key="index">
                            <el-card shadow="hover" class="movie-card" >
                                <img :src="movie.poster" alt="movie.name" class="movie-poster">
                                <div style="padding: 14px;">
                                    <div class="bottom clearfix">
                                        <h3 class="time">{{ movie.name }}</h3>
                                        <br>
                                        <el-button type="text" class="button" @click="ToCinema()">立刻购票</el-button>
                                    </div>
                                </div>
                            </el-card>
                        </el-col>
                    </el-row>
                </div>
            </el-main>
            <el-aside width="500px"><!--Aside-->
                <div class="rating-list">
                    <h3 class="title">高分推荐></h3>
                    <el-col 
                    v-for="(item, index) in ratings" 
                    :key="index" 
                    :class="[getRankClass(index)]"
                    :span="24"
                    >
                    <el-card shadow="hover" class="movie-info">
                        <div class="rank" :class="getRankColorClass(index)">{{ index + 1 }}</div>
                        <div class="name">{{ item.name }}</div>
                        <el-rate 
                        v-model="item.score" 
                        disabled 
                        show-score 
                        text-color="#ff9900" 
                        score-template="{value}"
                        ></el-rate>
                    </el-card>
                    </el-col>
                </div>
            </el-aside>
        </el-container>
        <el-footer>Footer</el-footer>
    </el-container>
</template>

<style scoped lang="less">
    .title{
        margin-left: 20px;
        margin-bottom: 10px;
        text-align: left;
    }

    .rating-list {
  /* 可以根据需要添加额外样式 */
        margin-top: 30px;
    }
    .movie-info {
        display: flex; /* 使用Flex布局 */
        //align-items: center; /* 垂直居中对齐 */
        //justify-content: space-between; /* 在两端对齐，中间留有空白 */
        flex-wrap: nowrap; /* 防止换行 */
        gap: 10px; /* 为元素间添加间隔，如果需要的话 */
    }
    .rank {
    display: inline-block;
    width: 60px; /* 根据需要调整宽度 */
    text-align: right;
    padding-right: 10px;
    }
    .bold {
    font-weight: bold;
    }
    .red {
    color: red;
    }
    .orange {
    color: orange;
    }
    .yellow {
    color: yellow;
    }
    .name {
    margin-left: 10px;
    }

    .movie-card{
        padding: 0px; 
        margin-bottom: 20px;
    }
    .movie-poster {
        width: 100%;
        height: auto;
    }
    .el-header, .el-footer {
        margin-top: 10px;
        background-color: #e3d6f5;
        color: #333;
        text-align: center;
        line-height: 60px;
    }

</style>

<script>
    import BookingButton from '../../components/BookButton.vue';
    export default {
        components:{
            BookingButton
        },
        data(){
            return{
                ratings: [
                    { name: '电影A', score: 4.5 },
                    { name: '电影B', score: 4.0 },
                    { name: '电影C', score: 3.5 },
                    { name: '电影C', score: 3.5 },
                    { name: '电影C', score: 3.5 },
                    { name: '电影C', score: 3.5 },
                    // 更多电影...
                ],
                movies: [
                    {
                    name: '《流浪地球》',
                    poster: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'
                    },
                    {
                    name: '《头号玩家》',
                    poster: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'
                    },
                    {
                    name: '《头号玩家》',
                    poster: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'
                    },
                    {
                    name: '《头号玩家》',
                    poster: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'
                    },
                    {
                    name: '《头号玩家》',
                    poster: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'
                    },
                    {
                    name: '《头号玩家》',
                    poster: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'
                    }
                    // 更多电影...
                ]
            }
        },
        methods: {
            /*
            <el-button type="text" class="button" @click="Book(movie.name,movie.poster)">立刻购票</el-button>
            Book(name,poster){
                //this.$router.push('/ticket');
                this.$router.push({ path: `/ticket/${encodeURIComponent(name)}/${encodeURIComponent(poster)}` })
            },*/
            // 返回排名对应的类名
            getRankClass(index) {
                return { first: index === 0, second: index === 1, third: index === 2 };
            },
            // 返回排名颜色的类名
            getRankColorClass(index) {
                return { red: index === 0, orange: index === 1, yellow: index === 2, bold: true };
            },
        }
    }
</script>

