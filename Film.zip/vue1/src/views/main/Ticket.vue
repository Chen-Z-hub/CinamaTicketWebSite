<template>
    <div>
        <br><br>
        <img :src="poster" alt="movie.name" class="movie-poster">
        <p>{{name}}</p>
        <Booking @listReturned="handleListReturned"/>
    </div>
</template>

<script>
import Booking from '../../components/Booking.vue';
export default {
    data(){
        return{
            name:'',
            poster:''
        }
    },
    components:{
        Booking
    },
    created() {
        const name = this.$route.params.name;
        const poster = this.$route.params.poster;
        // 将获取到的name参数值赋给data中的name属性
        if (name) {
            this.name = name;
        }
        if (poster) {
            this.poster = poster;
        }
    },
    methods: {
        handleListReturned(sendListFromChild) {
            // 这里可以使用从子组件传来的数据
            console.log("从子组件接收到的数据:", sendListFromChild,"电影名称",this.name);
            // 根据需要处理数据，比如更新父组件的状态等
        }
    }
}
</script>

<style>

</style>